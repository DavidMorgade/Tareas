package com.mycompany.megapoly.Sonido;

public class SonidoParking extends Sonidos {

  public SonidoParking() {
    super.ruta =
      "C:/Users/david/Documents/DAM/MegaPoly/MegaPoly/sounds/SonidoParking.wav";
  }
}
