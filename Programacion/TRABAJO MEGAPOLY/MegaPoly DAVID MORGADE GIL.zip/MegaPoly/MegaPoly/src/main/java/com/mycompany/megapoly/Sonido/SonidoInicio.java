package com.mycompany.megapoly.Sonido;

public class SonidoInicio extends Sonidos {

  public SonidoInicio() {
    super.ruta =
      "C:/Users/david/Documents/DAM/MegaPoly/MegaPoly/sounds/MusicaIntroduccion.wav";
  }
}
