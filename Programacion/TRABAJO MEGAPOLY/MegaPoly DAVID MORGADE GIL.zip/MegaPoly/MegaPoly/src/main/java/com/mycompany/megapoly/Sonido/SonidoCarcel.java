package com.mycompany.megapoly.Sonido;

public class SonidoCarcel extends Sonidos {

  public SonidoCarcel() {
    super.ruta =
      "C:/Users/david/Documents/DAM/MegaPoly/MegaPoly/sounds/SonidoCarcel.wav";
  }
}
