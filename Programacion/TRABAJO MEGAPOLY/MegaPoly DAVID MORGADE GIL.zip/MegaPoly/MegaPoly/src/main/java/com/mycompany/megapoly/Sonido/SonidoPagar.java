package com.mycompany.megapoly.Sonido;

public class SonidoPagar extends Sonidos {

  public SonidoPagar() {
    super.ruta =
      "C:/Users/david/Documents/DAM/MegaPoly/MegaPoly/sounds/SonidoPagar.wav";
  }
}
