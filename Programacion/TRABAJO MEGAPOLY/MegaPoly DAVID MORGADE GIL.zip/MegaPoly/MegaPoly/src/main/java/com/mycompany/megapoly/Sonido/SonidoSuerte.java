package com.mycompany.megapoly.Sonido;

public class SonidoSuerte extends Sonidos {

  public SonidoSuerte() {
    super.ruta =
      "C:/Users/david/Documents/DAM/MegaPoly/MegaPoly/sounds/SonidoSuerte.wav";
  }
}
