package com.mycompany.megapoly.Acciones;

public class RecompensaSalida {

  private int recompensa;

  public RecompensaSalida() {
    this.recompensa = 20;
  }

  public int getRecompensa() {
    return this.recompensa;
  }
}
